#!/bin/sh -
# On device, as root must do:
# mkdir /usr/share/jive/applets/IrServer
scp COPYING_*.txt IrServer* strings.txt root@192.168.0.74:/usr/share/jive/applets/IrServer/.
